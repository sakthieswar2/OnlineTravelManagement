﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using UserRegistrationService.Models;

namespace UserRegistrationService.DBContexts
{
    public class UserContext : DbContext
    {
        public UserContext(DbContextOptions<UserContext> options) : base (options)
        {

        }
        public DbSet<User> users { get; set; }
        public DbSet<UserRole> userRoles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //WIN2012BASE,2433
            modelBuilder.Entity<UserRole>().HasData(
                new UserRole
                {
                    RoleId = 1,
                    RoleName = "Admin"
                },
                new UserRole
                {
                    RoleId = 2,
                    RoleName = "Employee"
                },
                new UserRole
                {
                    RoleId = 3,
                    RoleName = "Consumer"
                }
            );
        }

    }
}
