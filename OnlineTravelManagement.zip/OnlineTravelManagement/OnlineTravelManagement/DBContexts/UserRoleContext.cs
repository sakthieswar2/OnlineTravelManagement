﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserRegistrationService.DBContexts
{
    public class UserRoleContext
    {
    }
}
