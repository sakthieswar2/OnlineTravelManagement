﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserRegistrationService.Models
{
    public interface IUser
    {
        int userId { get; set; }
        string userName { get; set; }
        string email { get; set; }
        string password { get; set; }

        void GetUser(string email, string password);

    }
}
