﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserRegistrationService.Models;

namespace UserRegistrationService.Repository
{
    interface IUserRepository
    {
        IEnumerable<User> getUsers();
        User getUserById(int userId);
        void addUser(User user);
        void deleteUser(int userId);
        void updateUser(User user);


    }
}
