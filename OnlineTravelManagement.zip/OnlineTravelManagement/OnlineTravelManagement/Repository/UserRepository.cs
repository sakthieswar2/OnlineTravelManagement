﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserRegistrationService.DBContexts;
using UserRegistrationService.Models;

namespace UserRegistrationService.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly UserContext _dbContext;

        public UserRepository(UserContext dbContext)
        {
            _dbContext = dbContext;
        }
        public void addUser(User user)
        {
            _dbContext.Add(user);
            Save();
        }

        public void deleteUser(int userId)
        {
            var user = _dbContext.users.Find(userId);
            _dbContext.users.Remove(user);
            Save();
        }

        public User getUserById(int userId)
        {
            return _dbContext.users.Find(userId);
        }

        public IEnumerable<User> getUsers()
        {
            return _dbContext.users.ToList();
        }

        public void updateUser(User user)
        {
            _dbContext.Entry(user).State = EntityState.Modified;
            Save();
        }

        public void Save()
        {
            _dbContext.SaveChanges();
        }
    }
}
